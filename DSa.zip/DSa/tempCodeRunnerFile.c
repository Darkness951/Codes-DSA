    // for (int i = 0; i < vertices; ++i) {
    //     Node* current = graph->array[i].head;
    //     while (current != NULL) {
    //         Node* next = current->next;
    //         free(current);
    //         current = next;
    //     }
    // }
    // free(graph->array);
    // free(graph);