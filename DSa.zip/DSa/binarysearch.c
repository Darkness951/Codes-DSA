#include<stdio.h>
 int main()
 {
 int i, j, n, arr[100], search, first, last, middle, temp;
 printf("how many element you want to store in array ? ");
 scanf("%d", &n);
 printf("\nenter array elements:");
 for(i=0; i<n; i++)
 scanf("%d", &arr[i]);
 printf("\nenter element to be search: ");
 scanf("%d", &search);
 // sorting given array using bubble sort
 for(i=0; i<(n-1); i++)
 {
 for(j=0; j<(n-i-1); j++)
{
 if(arr[j]>arr[j+1])
 {
     temp = arr[j];
 arr[j] = arr[j+1];
 arr[j+1] = temp;
  }
 }
 }
  printf("\nnow the sorted array is:\n");
 for(i=0; i<n; i++)
 printf("%d ", arr[i]);
 // back to binary search
 first = 0;
 last = n-1;
 middle = (first+last)/2;
 while(first <= last)
 {
 if(arr[middle]<search)
 first = middle+1;
 else if(arr[middle]==search)
 {
 printf("\n\nthe number, %d found at position %d", search, middle);
 break;
 }
else
 last = middle-1;
 middle = (first+last)/2;
 }
 if(first>last)
 printf("\nthe number, %d is not found in given array", search);
 return 0;
 }