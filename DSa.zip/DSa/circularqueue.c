#include<stdio.h>
#include<stdlib.h>

#define MAX_SIZE 5

int front = -1, rear = -1;
int queue[MAX_SIZE];

void enqueue(int value) {
    if ((front == 0 && rear == MAX_SIZE - 1) || (rear == (front - 1) % (MAX_SIZE - 1))) {
        printf("Queue is full. Cannot enqueue %d\n", value);
    } else if (front == -1 && rear == -1) {
        front = rear = 0;
        queue[rear] = value;
        printf("%d enqueued to the queue\n", value);
    } else {
        rear = (rear + 1) % MAX_SIZE;
        queue[rear] = value;
        printf("%d enqueued to the queue\n", value);
    }
}

int dequeue() {
    int removedValue;
    if (front == -1) {
        printf("Queue is empty. Cannot dequeue.\n");
        return -1;
    } else {
        removedValue = queue[front];
        if (front == rear) {
            front = rear = -1;
        } else {
            front = (front + 1) % MAX_SIZE;
        }
        printf("%d dequeued from the queue\n", removedValue);
        return removedValue;
    }
}

void display() {
    int i;
    if (front == -1) {
        printf("Queue is empty\n");
    } else {
        printf("Elements in the queue are:\n");
        for (i = front; i != rear; i = (i + 1) % MAX_SIZE) {
            printf("%d ", queue[i]);
        }
        printf("%d\n", queue[i]);
    }
}

int main() {
    enqueue(1);
    enqueue(2);
    enqueue(3);
    enqueue(4);
    display();

    dequeue();
    dequeue();
    display();

    enqueue(5);
    enqueue(6);
    display();

    return 0;
}
