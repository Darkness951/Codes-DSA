#include<stdio.h> 
#define SIZE 10 

void push(int); 
int pop();  
void disp(); 
void peek(); 

int stack[SIZE], top = -1; 

int main()  
{ 
    int value;
    int choice;

    do { 
        printf("\n\n***** MENU *****\n"); 
        printf("1. Push\n2. Pop\n3. Display\n4. Peek\n5. Exit\n"); 
        printf("\nEnter your choice: "); 
        scanf("%d", &choice); 

        switch (choice) { 
            case 1: 
                printf("Enter the value to be inserted: "); 
                scanf("%d", &value); 
                push(value); 
                break; 
            case 2: 
                value = pop(); 
                printf("Deleted element is %d", value); 
                break; 
            case 3: 
                disp(); 
                break; 
            case 4: 
                peek(); 
                break; 
        }  
    } while (choice != 5);

    return 0; 
}

void push(int value) 
{ 
    if (top == SIZE-1) 
        printf("\nStack is Full!!! Insertion is not possible!!!"); 
    else { 
        top++; 
        stack[top] = value; 
        printf("\nInsertion success!!!"); 
    } 
} 

int pop() 
{ 
    int popped_value = -1;

    if (top == -1) 
        printf("\nStack is Empty!!! Deletion is not possible!!!"); 
    else { 
        popped_value = stack[top]; 
        top--; 
    }

    return popped_value;
} 

void peek() 
{ 
    if (top == -1) 
        printf("\nStack is Empty!!!"); 
    else 
        printf("Stack top is %d", stack[top]); 
} 

void disp() 
{ 
    if (top == -1) 
        printf("\nStack is Empty!!!"); 
    else { 
        int i; 
        printf("\nStack elements are:\n"); 
        for (i = top; i >= 0; i--) 
            printf("%d\n", stack[i]); 
    } 
}
