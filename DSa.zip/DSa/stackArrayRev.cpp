#include<stdio.h>
#include<stdlib.h>

struct stack{
    int size;
    int top;
    int * arr;
};

int isFull(struct stack* ptr)
{
    if(ptr->top == ptr->size-1)
    return 1;
    else
    return 0;
}
int isEmpty(struct stack* ptr)
{
    if(ptr->top == -1)
    return 1;
    else
    return 0;
}

void push(struct stack* ptr, int val)
{
    if(isFull(ptr))
    {
        printf("Stack overflow!\n");
    }
    else
    {
        ptr->top++;
        ptr->arr[ptr->top] = val;
    }
}

int pop(struct stack* ptr)
{
    if(isEmpty(ptr))
    {
        printf("Stack underflow!\n");
        return -1;
    }
    else
    {
        int val = ptr->arr[ptr->top];
        ptr->top--;
        return val;
    }
}

int peek( struct stack* ptr, int i)
{
    int index = ptr->top-i+1;
    if(index<0)
    {
        printf("Not a valid index for stack");
        return -1;
    }
    else
    {
        return ptr->arr[index];
    }
}

void display(struct stack* ptr)
{
    if(isEmpty(ptr))
    printf("Stack underflow!");
    else
    {
        for(int i=ptr->top;i>=0;i--)
        printf("%i\n",ptr->arr[i]);
    }
}

int main(void)
{
    struct stack* sp= (struct stack*)malloc(sizeof(struct stack));
    sp->top=-1;
    sp->size= 100;
    sp->arr = (int *)malloc((sp->size)* sizeof(int));
    printf("Stack has been created succesfully\n");
    int value,choice,i;
    do{ 
    printf("Enter 1 to push, 2 to pop, 3 to display, 4 to peek and 5 to exit\n ");
    printf("Enter your choice\n");
    scanf("%i\n",&choice);
    switch(choice)
    {
      case 1:
      printf("Enter value\n");
      scanf("%i\n",&value);
      push(sp,value);
      break;
      case 2:
      if(pop(sp)!=-1)
      printf("popped value= %i\n",pop(sp));
      break;
      case 3: display(sp);
      break;
      case 4: 
      printf("Enter the value of index ro peek at\n ");
      scanf("%i\n",&i);
      if(peek(sp,i)!=-1)
      printf("Value at index %i = %i\n",i,peek(sp,i));
      break;
    }
}while(choice!=5);
}