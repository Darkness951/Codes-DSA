#include<stdio.h>
#include<stdlib.h>

struct node
{
    int data;
    struct node* next;
};

void trav(struct node * ptr)
{
    while(ptr!=NULL)
    {
        printf("element: %i\n",ptr->data);
        ptr = ptr->next;
    }
}

struct node* create(struct node * ptr, int data)
{
    ptr= (struct node*)malloc(sizeof(struct node));
    ptr->data = data;
    ptr->next = NULL;
    return ptr;
}

struct node* insertAtBeg(struct node * head,int val)
{
    struct node * ptr=(struct node*)malloc(sizeof(struct node));
    ptr->data = val;
    struct node* p= head;
    ptr->next = p;
    head = ptr;
    return head;
}

struct node* insertAtPos(struct node * head, int val, int pos)
{
    struct node * ptr2=(struct node*)malloc(sizeof(struct node));
    ptr2->data = val;
    ptr2->next =  NULL;
    struct node* ptr= head;
    pos--;
    while(pos!=1)
    {
        ptr = ptr->next;
        pos--;
    }
   ptr2->next = ptr->next;
   ptr->next = ptr2;
    return head;
}

struct node* insertAtLast(struct node * head, int val)
{
    struct node * ptr=(struct node*)malloc(sizeof(struct node));
    ptr->data = val;
    struct node* p= head;
    while(p->next!=NULL)
    {
        p=p->next;
    }
    p->next = ptr;
    ptr->next = NULL;
    return head;
}

struct node * insertAfterIndex(struct node* head, struct node* prevNode, int val)
{
   struct node * ptr = (struct node *) malloc(sizeof(struct node));
    ptr->data = val;
    ptr->next = prevNode->next;
    prevNode->next = ptr;
    return head;
}

struct node*delFirst(struct node* head)
{
    if(head == NULL)
    {
        printf("Linked list is already empty\n");
    }
    else if (head->next == NULL)
    {
        free(head);
        head = NULL;
    }
    else
    {
        struct node* temp = head;
        head = head->next;
        free(temp);
        temp=NULL;
    }
    return head;
}

struct node* delLast(struct node* head)
{
    if(head == NULL)
    printf("Linked list is already empty\n");
    else if( head->next == NULL)
    {
        free(head);
        head = NULL;
    }
    else
    {
        struct node * p = head;
        struct node * q = head->next;
        while(q->next!=NULL)
        {
            p=p->next;
            q=q->next;
        }
        p->next = NULL;
        free(q);
        q = NULL;
    }
    return head;
}

void delAtPos(struct node* *head, int pos)
{
    struct node* prev = *head;
    struct node* curr = *head;
    if(*head == NULL)
    {
        printf("Linked list is already empty\n");
    }
    else if(pos == 1)
    {
       *head = curr->next;
       free(curr);
       curr = NULL;
    }
    else
    {
        while(pos!=1)
        {
            prev = curr;
            curr = curr->next;
            pos--;
        }
        prev->next = curr->next;
        free(curr);
        curr = NULL;
    }
         
}

struct node* delParticularVal(struct node* head, int val)
{
    if(head==NULL)
    printf("Linked list is already empty\n");
    else
    {
        struct node* p= head;
        struct node* q = head->next;
        while(q->data!=val && q->next!=NULL)
        {
            q=q->next;
            p=p->next;
        }
        if(q->data == val)
        {
            p->next = q->next;
            free(q);
        }
        return head;
    }
}

int main(void)
{
    struct node* head =NULL;
    int data;
    printf("Enter data for head of linked list\n");
    scanf("%i\n",&data);
    head = create(head,data);
    int choice,i,val,n;
    while(1) 
    { 
    printf("Enter 1 to create linked list,\n 2 to insert node at beginning,\n 3 to insert node at last,\n 4 to insert node at a particular index\n");
    printf("5 to delete the first node\n 6 to delete last node,\n 7 to delete node at a particular index,\n 8 to delete node with a particular value\n");
    printf("9 to display linked list \n 10 to exit\n");
    printf("Enter your choice=\n");
    scanf("%i\n",&choice);
    fflush(stdin);
    switch (choice)
    {
    case 1:
        printf("Enter the number of nodes you want to add to head of linked list\n");
        scanf("%i\n",&n);
        
        for(int i=0;i<n;i++)
        {
            printf("Enter the value for new node\n");
            scanf("%i\n",&val);
            fflush(stdin);
            head = insertAtLast(head, val);
        }
        break;
    case 2:
    printf("Enter the value for new node\n");
    scanf("%i\n",&val);
    fflush(stdin);
    head = insertAtBeg(head,val);
    break;
    case 3: 
    printf("Enter the value for new node\n");
    scanf("%i\n",&val);
    
    head = insertAtLast(head,val);
    break;
    case 4:
     printf("Enter the value for new node\n");
    scanf("%i\n",&val);
    fflush(stdin);
    printf("Enter the value of index\n");
    scanf("%i\n",&i);
    fflush(stdin);
    head = insertAtPos(head,val,i);
    break;
    case 5:
    head = delFirst(head);
    break;
    case 6:
    head = delLast(head);
    break;
    case 7:
    printf("Enter the index you want to delete\n");
    scanf("%i\n",&i);
    fflush(stdin);
     delAtPos(&head,i);
    break;
    case 8:
    printf("Enter the value of node you want to delete\n");
    scanf("%i\n",&val);
    fflush(stdin);
    head = delParticularVal( head,val);
    break;
    case 9:
    if(head == NULL)
    printf("Linked list is empty\n");
    else
    trav(head);
    break;
    case 10: exit(0);
    }
      }
}