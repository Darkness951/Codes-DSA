#include <stdio.h>
#include <stdlib.h>
#define SIZE 5

int main()
{
    int i;
    int flag = 1;
    int arr[SIZE]={1,3,3,2,1};

    for(i=0;i<SIZE/2;i++)
    {
        if(arr[i] != arr[SIZE-1-i])
        {
            flag = 0;
            break;
        }
    }
 
if (flag ==1)
printf("The array is a palindrome.\n");
else if(flag==0)
 printf("array is not a palindrome.\n");

 }

