#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

typedef struct {
    Node* head;
} AdjList;

typedef struct {
    int vertices;
    AdjList* array;
} Graph;

Graph* createGraph(int vertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    graph->vertices = vertices;
    graph->array = (AdjList*)malloc(vertices * sizeof(AdjList));

    for (int i = 0; i < vertices; ++i)
        graph->array[i].head = NULL;

    return graph;
}

void addEdge(Graph* graph, int src, int dest) {

    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = dest;
    newNode->next = graph->array[src].head;
    graph->array[src].head = newNode;


}

void DFSUtil(Graph* graph, int vertex, int* visited) {

    visited[vertex] = 1;
    printf("%d ", vertex);

    Node* temp = graph->array[vertex].head;
    while (temp != NULL) {
        int adjacentVertex = temp->data;
        if (!visited[adjacentVertex]) {
            DFSUtil(graph, adjacentVertex, visited);
        }
        temp = temp->next;
    }
}

void DFS(Graph* graph, int startVertex) {

    int* visited = (int*)malloc(graph->vertices * sizeof(int));
    for (int i = 0; i < graph->vertices; ++i)
        visited[i] = 0;

    printf("Depth-First Search starting from vertex %d:\n", startVertex);
    DFSUtil(graph, startVertex, visited);

    printf("\n");

    free(visited);
}

int main() {
    int vertices = 6;
    Graph* graph = createGraph(vertices);

    addEdge(graph, 0, 1);
    addEdge(graph, 0, 2);
    addEdge(graph, 1, 3);
    addEdge(graph, 1, 4);
    addEdge(graph, 2, 4);
    addEdge(graph, 3, 5);
    addEdge(graph, 4, 5);

//gauri use this one addEdge(graph, 0, 1);
// addEdge(graph, 0, 2);
// addEdge(graph, 1, 3);
// addEdge(graph, 1, 4);
// addEdge(graph, 2, 4);
// addEdge(graph, 3, 5);
// addEdge(graph, 4, 5);


    DFS(graph, 0);


    for (int i = 0; i < vertices; ++i) {
        Node* current = graph->array[i].head;
        while (current != NULL) {
            Node* next = current->next;
            free(current);
            current = next;
        }
    }
    free(graph->array);
    free(graph);

    return 0;
}
