#include <stdio.h>
#include <stdio.h>

struct node{
    int data;
    struct node *link;
};

int main() {
    struct node *head= (struct node *)malloc(sizeof(struct node));
    head->data = 45;
    
    struct node *current= (struct node *)malloc(sizeof(struct node));
    current->data = 45;
    head->link = current;
}

